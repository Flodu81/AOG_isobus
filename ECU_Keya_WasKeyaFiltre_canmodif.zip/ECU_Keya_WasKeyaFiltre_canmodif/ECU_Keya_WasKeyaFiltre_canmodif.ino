#define AOG_SKETCH_KEYA //FlorianT section control

#define VERSION 1.02
//  0 = Claas (1E/30 Navagation Controller, 13/19 Steering Controller) - See Claas Notes on Service Tool Page
//  1 = Valtra, Massey Fergerson (Standard Danfoss ISO 1C/28 Navagation Controller, 13/19 Steering Controller)
//  2 = CaseIH, New Holland (AA/170 Navagation Controller, 08/08 Steering Controller)
//  3 = Fendt (2C/44 Navagation Controller, F0/240 Steering Controller)
//  4 = JCB (AB/171 Navagation Controller, 13/19 Steering Controller)
//  5 = FendtOne - Same as Fendt but 500kbs K-Bus.
uint8_t Brand = 5;  

enum PositionType { LATITUDE, LONGITUDE }; //FlorianT
bool nmeaoutput = 0;
bool sectionout = 0; 

/************************* User Settings *************************/
// Serial Ports
#define SerialAOG Serial                //AgIO USB conection
HardwareSerial* SerialGPS = &Serial3;   //Main postion receiver (GGA)
HardwareSerial* SerialImu = &Serial7;   //TM171
Stream* NmeaOutputSerial = &Serial8;   //NMEA out

const int32_t baudAOG = 115200; 
const int32_t baudGPS = 460800;

int8_t KeyaCurrentSensorReading = 0;

#define ImuWire Wire        //SCL=19:A5 SDA=18:A4
#define RAD_TO_DEG_X_10 572.95779513082320876798154814105

const bool invertRoll= true;  //Used for IMU with dual antenna
#define baseLineLimit 5       //Max CM differance in baseline

#define REPORT_INTERVAL 20    //BNO report time, we want to keep reading it quick & offen. Its not timmed to anything just give constant data.
uint32_t READ_BNO_TIME = 0;   //Used stop BNO data pile up (This version is without resetting BNO everytime)

uint32_t gpsReadyTime = 0;        //Used for GGA timeout

//Speed pulse output
elapsedMillis speedPulseUpdateTimer = 0;
byte velocityPWM_Pin = 32;      // Velocity (MPH speed) PWM pin
#define SPEED_PULSE_IMP_PER_METER 130.00f  // Nbre de metre par imp, ex : 8 imp/tour, pneu 18.4 R38 (5.61m circ) 1.426 imp/m

struct Setup {
	uint8_t InvertWAS = 0;
	uint8_t IsRelayActiveHigh = 0;    // if zero, active low (default)
	uint8_t MotorDriveDirection = 0;
	uint8_t SingleInputWAS = 1;
	uint8_t CytronDriver = 1;
	uint8_t SteerSwitch = 0;          // 1 if switch selected
	uint8_t SteerButton = 0;          // 1 if button selected
	uint8_t ShaftEncoder = 0;
	uint8_t PressureSensor = 0;
	uint8_t CurrentSensor = 0;
	uint8_t PulseCountMax = 5;
	uint8_t IsDanfoss = 0;            // 0 = WAS physique ADS1115 | 1 = Encodeur Keya + auto-zero
	uint8_t IsUseY_Axis = 0;

}; Setup steerConfig;
// ------------------------------------


// -----------------------------------------------------------------------
// MODE IsDanfoss :
//   IsDanfoss = 0 -> WAS physique via ADS1115 (code original), pas d'auto-zero
//   IsDanfoss = 1 -> WAS via encodeur Keya + auto-zero automatique (code modifie)
// La variable steerConfig.IsDanfoss est lue depuis AgOpenGPS (PGN 251 bit0 byte8)
// -----------------------------------------------------------------------

// -----------------------------------------------------------------------
// AUTO-ZERO WAS – remise a zero automatique (BNO cap stable -> position = 0deg)
// Utilise uniquement si IsDanfoss == 1
// -----------------------------------------------------------------------
static float    wasOffsetF   = 0.0f;
static uint32_t stableStart  = 0;

static const float    AUTOZERO_SPEED_MIN    = 4.0f;
static const float    AUTOZERO_YAWRATE_MAX  = 0.5f;
static const float    AUTOZERO_DELTA_MAX    = 20.0f;
static const float    AUTOZERO_BETA         = 0.3f;
static const float    AUTOZERO_SPEED_SLOW   = 3.0f;
static const float    AUTOZERO_SPEED_FAST   = 12.0f;
static const uint32_t AUTOZERO_TIME_SLOW_MS = 500;
static const uint32_t AUTOZERO_TIME_FAST_MS = 200;
#define EEPROM_ADDR_WAS_OFFSET_F  80

// -----------------------------------------------------------------------
// ENCODEUR KEYA comme WAS (remplace ADS1115)
// Utilise uniquement si IsDanfoss == 1
//
// Le heartbeat Keya (ID 0x07000001, bytes 0-1) contient un compteur
// cumulatif uint16 : 65535 ticks = 1 tour moteur.
// On accumule les deltas (int16 signe) dans keyaEncoderRaw (int32).
//
// RATIO MECANIQUE (a calibrer) :
//   Butee a butee = 60deg braquage roue = ~4 tours moteur
//   4 x 65535 = 262140 ticks -> KEYA_TICKS_PER_DEG ~ 4369 ticks/deg
//   Sauvegarde EEPROM adresse 84 pour modification sans recompilation.
// -----------------------------------------------------------------------
#define KEYA_TICKS_PER_DEG_DEFAULT  24.0f     // 4 tours x 360 ticks/tour / 60deg = 24 ticks/deg
#define KEYA_STEER_RANGE_DEG        30.0f
#define EEPROM_ADDR_KEYA_TICKS      84

float    keyaTicksPerDeg = KEYA_TICKS_PER_DEG_DEFAULT;
int32_t  keyaZeroTicks   = 0;
bool     wasZeroDone     = false;

// Variables declarees dans KeyaCANBUS.ino – forward declaration pour Autosteer.ino
extern int32_t  keyaEncoderRaw;
extern bool     keyaEncInitDone;

// Variables declarees dans zHandlers.ino
extern char vtgHeading[12];
extern float emaGpsHdg;

/*****************************************************************/

// Ethernet Options (Teensy 4.1 Only)
#ifdef ARDUINO_TEENSY41
#include <NativeEthernet.h>
#include <NativeEthernetUdp.h>

//---- IsoBridge host settings ---- //Isobus udp
#define ISO_ETHERNET_UP    Ethernet_running       //stock AiO flag, set in EthernetStart()
#define ISO_STEER_ENGAGED  (guidanceStatus != 0)  //only reported to the PC, optional
#define ISO_ALWAYS_ON                             //see "No console?" below

struct ConfigIP {
    uint8_t ipOne = 192;
    uint8_t ipTwo = 168;
    uint8_t ipThree = 1;
};  ConfigIP networkAddress;   //3 bytes

// IP & MAC address of this module of this module
byte Eth_myip[4] = { 0, 0, 0, 0}; //This is now set via AgIO
byte mac[] = {0x00, 0x00, 0x56, 0x00, 0x00, 0x78};

unsigned int portMy = 5120;             // port of this module
unsigned int AOGNtripPort = 2233;       // port NTRIP data from AOG comes in
unsigned int AOGAutoSteerPort = 8888;   // port Autosteer data from AOG comes in
unsigned int portDestination = 9999;    // Port of AOG that listens
char Eth_NTRIP_packetBuffer[512];       // buffer for receiving ntrip data

// An EthernetUDP instance to let us send and receive packets over UDP
EthernetUDP Eth_udpPAOGI;     //Out port 5544
EthernetUDP Eth_udpNtrip;     //In port 2233
EthernetUDP Eth_udpAutoSteer; //In & Out Port 8888
IPAddress Eth_ipDestination;

#endif // ARDUINO_TEENSY41

#include "zNMEAParser.h"
#include <Wire.h>
#include "BNO08x_AOG.h"

#include <FlexCAN_T4.h>
FlexCAN_T4<CAN2, RX_SIZE_256, TX_SIZE_256> K_Bus;    //Tractor / Control Bus
FlexCAN_T4<CAN3, RX_SIZE_256, TX_SIZE_256> isoCan;  //ISO Bus 
FlexCAN_T4<CAN1, RX_SIZE_256, TX_SIZE_256> Keya_Bus;

#define ISO_CAN_BASE CAN3    //Numero Can isoCan pour isobus
#define ISO_CAN_BUS_NUM 3    //Numero Can isoCan pour isobus

auto& Sc_Bus = isoCan; // Choix de l'affectation du CAN pour le section control

//Used to set CPU speed
extern "C" uint32_t set_arm_clock(uint32_t frequency); // required prototype

// booleans to see if we are using BNO08x
bool useBNO08x = false;

elapsedMillis imuTimer;
bool imuTrigger = false;

bool useTM171 = false;
elapsedMillis TM171lastData;

// BNO08x address variables to check where it is
const uint8_t bno08xAddresses[] = { 0x4A, 0x4B };
const int16_t nrBNO08xAdresses = sizeof(bno08xAddresses) / sizeof(bno08xAddresses[0]);
uint8_t bno08xAddress;
BNO080 bno08x;

constexpr int serial_buffer_size = 512;
uint8_t GPSrxbuffer[serial_buffer_size];    //Extra serial rx buffer
uint8_t GPStxbuffer[serial_buffer_size];    //Extra serial tx buffer
uint8_t RTKrxbuffer[serial_buffer_size];    //Extra serial rx buffer

/* A parser is declared with 3 handlers at most */
NMEAParser<3> parser; // Modif FlorianT NMEAOUT

bool isTriggered = false;
bool blink = false;

bool Autosteer_running = true; //Auto set off in autosteer setup
bool Ethernet_running = false; //Auto set on in ethernet setup
bool GGA_Available = false;    //Do we have GGA on correct port?

float roll = 0;
float pitch = 0;
float yaw = 0;

// Setup procedure ------------------------
void setup()
{
  delay(500);                         //Small delay so serial can monitor start up
  // the dash means wildcard
  parser.setErrorHandler(errorHandler);
  parser.addHandler("G-GGA", GGA_Handler);
  parser.addHandler("G-VTG", VTG_Handler);
  parser.addHandler("G-RMC", RMC_Handler); //FlorianT

  delay(10);
  Serial.begin(baudAOG);
  delay(10);
  Serial.println("Firmware : AutoSteer GPS Teensy Engage CAN And Keya for ECU PCB !");
  Serial.print("Version : ");
  Serial.println(VERSION);
  Serial.println("Start setup");

  SerialGPS->begin(baudGPS);
  SerialGPS->addMemoryForRead(GPSrxbuffer, serial_buffer_size);
  SerialGPS->addMemoryForWrite(GPStxbuffer, serial_buffer_size);

  delay(10);  
  Serial.println("SerialAOG, SerialRTK, SerialGPS initialized");

  Serial.println("\r\nStarting AutoSteer...");
  autosteerSetup();
  
  Serial.println("\r\nStarting Ethernet...");
  EthernetStart();

  isoSetup(); //Isobus udp

  Serial.println("\r\nStarting IMU...");
  //test if CMPS working
  uint8_t error;

  ImuWire.begin();
  
  for (int16_t i = 0; i < nrBNO08xAdresses; i++)
  {
      bno08xAddress = bno08xAddresses[i];

      ImuWire.beginTransmission(bno08xAddress);
      error = ImuWire.endTransmission();

      if (error == 0)
      {
          Serial.print("0x");
          Serial.print(bno08xAddress, HEX);
          Serial.println(" BNO08X Ok.");

          // Initialize BNO080 lib
          if (bno08x.begin(bno08xAddress, ImuWire))
          {
              //Increase I2C data rate to 400kHz
              ImuWire.setClock(400000); 

              delay(300);

              // Use gameRotationVector and set REPORT_INTERVAL
             // bno08x.enableGameRotationVector(REPORT_INTERVAL);
              bno08x.enableARVRStabilizedGameRotationVector(REPORT_INTERVAL);
              useBNO08x = true;
          }
          else
          {
              Serial.println("BNO080 not detected at given I2C address.");
          }
      }
      else
      {
          Serial.print("0x");
          Serial.print(bno08xAddress, HEX);
          Serial.println(" BNO08X not Connected or Found");
      }
      if (useBNO08x) break;
  }
        Serial.println("\r\nChecking for TM171");

        bool foundTM171 = false;


            if (TM171detectOnPort(SerialImu, 1500))
            {
                Serial.println("Received data from TM171 on Serial7");
                foundTM171 = true;
            }
        
        if (foundTM171)
        {
            useTM171 = true;
        }
        else
        {
            Serial.println("TM171 not Connected or Found");
        }
  delay(100);
  Serial.print("useBNO08x = ");
  Serial.println(useBNO08x);
  Serial.print("useTM171 = ");
  Serial.println(useTM171);

  Serial.println("Right... time for some CANBUS! And, we're dedicated to Keya here");
  CAN_Setup();
  if (nmeaoutput == 1)
  {
    setupNmeaOutput(); // FlorianT GPS Out
  }

  // Affichage du mode actif au demarrage
  if (steerConfig.IsDanfoss == 1) {
    Serial.println("[MODE] IsDanfoss=1 -> WAS via encodeur Keya + auto-zero actif");
  } else {
    Serial.println("[MODE] IsDanfoss=0 -> WAS physique ADS1115, pas d'auto-zero");
  }

  Serial.println("\r\nEnd setup, waiting for GPS...\r\n");
}

void loop()
{
    KeyaBus_Receive();
    webConfigLoop();

    // Read incoming nmea from GPS modif FlorianT
    if (SerialGPS->available())
    {
        parser << SerialGPS->read(); 
    }

    udpNtrip();
    if (nmeaoutput == 1)
    {
        SendNmea0183(); // FlorianT gpsout
    }

    //Read BNO
    if((systick_millis_count - READ_BNO_TIME) > REPORT_INTERVAL && useBNO08x)
    {
      READ_BNO_TIME = systick_millis_count;
      readBNO();
    }

    TM171process();
    if (useTM171 && imuTimer > 40 && imuTrigger)
    {
        imuTrigger = false;
        imuHandler();   //Get IMU data ready
    }
    
    isoLoop(); //Isobus udp

    if (Autosteer_running) autosteerLoop();
    else ReceiveUdp();



}//End Loop
